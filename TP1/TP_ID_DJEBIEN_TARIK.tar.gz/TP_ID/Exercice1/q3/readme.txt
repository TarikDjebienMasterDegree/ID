// README
// TP Entrepots de données 
// Exercice 1 : Schéma en etoile et rapports

Question 3 : Créer une base de données entrepôt qui implémente les schémas en etoiles de la question 2.
                   Alimenter cet entrepôt avec des requêtes ajout et en utilisant des données provenant des tables de la base de données Comptoir.

Le fichier entrepôt.sql regroupe les instructions SQL de creations du DataWarehouse pour l'étude des faits :
  - Le fait Ventes.
  - Le fait Achat.
  
Le fichier alimentation.sql regroupe les instructions SQL d'insertions des données provenant des tables de la base de données Comptoir.
  
  
Cordialement,

Djebien Tarik.
