package entrepot.bean.contrat;

public interface IFait {

}
