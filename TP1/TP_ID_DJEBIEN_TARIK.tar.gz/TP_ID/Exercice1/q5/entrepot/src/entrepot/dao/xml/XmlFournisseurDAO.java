package entrepot.dao.xml;

import entrepot.bean.dimension.Fournisseur;

public class XmlFournisseurDAO extends XmlDAO<Fournisseur> {

	@Override
	public boolean create(Fournisseur obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(Fournisseur obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(Fournisseur obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Fournisseur find(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
