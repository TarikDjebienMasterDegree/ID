package entrepot.bean.contrat;

public interface IDimension {

}
