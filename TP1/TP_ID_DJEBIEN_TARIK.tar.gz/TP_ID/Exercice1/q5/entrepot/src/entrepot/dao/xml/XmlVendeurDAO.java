package entrepot.dao.xml;

import entrepot.bean.dimension.Vendeur;

public class XmlVendeurDAO extends XmlDAO<Vendeur> {

	@Override
	public boolean create(Vendeur obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(Vendeur obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(Vendeur obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Vendeur find(int id) {
		// TODO Auto-generated method stub
		return null;
	}
}