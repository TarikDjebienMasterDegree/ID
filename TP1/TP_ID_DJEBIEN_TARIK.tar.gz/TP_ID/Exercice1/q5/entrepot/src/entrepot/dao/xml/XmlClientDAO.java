package entrepot.dao.xml;

import entrepot.bean.dimension.Client;

public class XmlClientDAO extends XmlDAO<Client> {

	@Override
	public boolean create(Client obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(Client obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(Client obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Client find(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
