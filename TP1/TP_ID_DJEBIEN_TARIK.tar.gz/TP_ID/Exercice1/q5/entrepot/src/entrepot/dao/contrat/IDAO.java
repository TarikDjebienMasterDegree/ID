package entrepot.dao.contrat;

public interface IDAO {

}
