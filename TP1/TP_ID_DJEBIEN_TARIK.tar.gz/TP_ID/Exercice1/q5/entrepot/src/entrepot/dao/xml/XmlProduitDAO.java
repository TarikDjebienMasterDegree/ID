package entrepot.dao.xml;

import entrepot.bean.dimension.Produit;

public class XmlProduitDAO extends XmlDAO<Produit> {

	@Override
	public boolean create(Produit obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(Produit obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(Produit obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Produit find(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
