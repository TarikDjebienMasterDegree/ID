package entrepot.dao.xml;

import entrepot.bean.dimension.Temps;

public class XmlTempsDAO extends XmlDAO<Temps> {

	@Override
	public boolean create(Temps obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(Temps obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(Temps obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Temps find(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
