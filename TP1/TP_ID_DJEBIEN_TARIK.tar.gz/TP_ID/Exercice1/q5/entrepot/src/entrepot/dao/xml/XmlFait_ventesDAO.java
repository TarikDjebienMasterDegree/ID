package entrepot.dao.xml;

import entrepot.bean.fait.Fait_ventes;

public class XmlFait_ventesDAO extends XmlDAO<Fait_ventes> {

	@Override
	public boolean create(Fait_ventes obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(Fait_ventes obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(Fait_ventes obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Fait_ventes find(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
