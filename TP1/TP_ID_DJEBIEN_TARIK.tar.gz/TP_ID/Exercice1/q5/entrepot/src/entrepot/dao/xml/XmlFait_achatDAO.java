package entrepot.dao.xml;

import entrepot.bean.fait.Fait_achat;

public class XmlFait_achatDAO extends XmlDAO<Fait_achat> {

	@Override
	public boolean create(Fait_achat obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(Fait_achat obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(Fait_achat obj) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Fait_achat find(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
